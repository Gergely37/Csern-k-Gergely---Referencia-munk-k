﻿using System.ComponentModel.DataAnnotations;

namespace NorthwindAPIDemo.Models
{
    public class UpdateCategoryRequest
    {
        [Required]
        public string CategoryName { get; set; }

        public string Description { get; set; }
    }
}
