﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using NorthwindAPIDemo.Data;
using NorthwindAPIDemo.Domain;
using NorthwindAPIDemo.Models;

namespace NorthwindAPIDemo.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly NorthwindContext _context;

        public CategoriesController(NorthwindContext context)
        {
            _context = context;
        }

        //[HttpGet]
        //public IEnumerable<Category> GetAll()
        //{
        //    return _context.Categories;
        //}

        //[HttpGet("{id}")]
        //public Category GetById(int id)
        //{
        //    return _context.Categories.FirstOrDefault(c => c.CategoryId == id);
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetAll()
        {
            var categories = _context.Categories;

            if (categories == null)
            {
                return NotFound();
            }

            return Ok(categories);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var category = _context.Categories.FirstOrDefault(c => c.CategoryId == id);

            if (category == null)
            {
                return NotFound();
            }

            return Ok(category);
        }

        [HttpGet("count")]
        public int Count() => _context.Categories.Count();

        [HttpGet("{id}/products")]
        public IEnumerable<Product> GetProductsByCategoryId(int id)
        {
            return _context.Products.Where(p => p.CategoryId == id);
        }

        // POST: .../api/Categories
        [HttpPost]
        public IActionResult Create([FromBody] CreateCategoryRequest request)
        {
            // Mapping
            var category = new Category
            {
                CategoryId = request.CategoryId,
                CategoryName = request.CategoryName,
                Description = request.Description
            };

            _context.Categories.Add(category);
            _context.SaveChanges();
            return Created(string.Empty, null);
        }

        [HttpPut("{id}")]
        public IActionResult Update(short id, [FromBody] UpdateCategoryRequest request)
        {
            var category = _context.Categories.SingleOrDefault(c => c.CategoryId == id);
            if (category is null)
                return NotFound();

            category.CategoryName = request.CategoryName;
            category.Description = request.Description;
            _context.Update(category);
            _context.SaveChanges();

            return Ok();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(short id)
        {
            var category = _context.Categories.SingleOrDefault(c => c.CategoryId == id);
            if (category is null)
                return NotFound();

            _context.Categories.Remove(category);
            _context.SaveChanges();

            return NoContent();
        }
    }
}
