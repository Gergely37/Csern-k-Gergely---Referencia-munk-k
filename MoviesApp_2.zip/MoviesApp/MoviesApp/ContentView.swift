//
//  ContentView.swift
//  MoviesApp
//
//  Created by Bolla Kálmán on 2022. 11. 07..
//

import SwiftUI

struct ContentView: View {
    
    var array: [String] = Array(repeating: "alma", count: 100)
    
    var body: some View {
        //MovieDetailsView()
        NavigationView {
            List(array, id: \.self) { a in
                NavigationLink {
                    //Text("alma részletes nézet")
                    MovieDetailsView()
                } label: {
                    Text(a)
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
