//
//  MoviesAppApp.swift
//  MoviesApp
//
//  Created by Bolla Kálmán on 2022. 11. 07..
//

import SwiftUI

@main
struct MoviesAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
