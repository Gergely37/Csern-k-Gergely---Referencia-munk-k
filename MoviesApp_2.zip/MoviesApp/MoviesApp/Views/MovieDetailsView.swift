//
//  MovieDetailsView.swift
//  MoviesApp
//
//  Created by Bolla Kálmán on 2022. 11. 14..
//

import SwiftUI

struct MovieDetailsView: View {
    
    let alma = "alma"
    let originalTitle = "Fight club"
    
    @State var movie = MovieDetailsResponse()
    
    var body: some View {
        Form {
            Section {
                AsyncImage(url: URL(string: movie.posterPath!)) { phase in
                    switch phase {
                        case .success(let image):
                            image
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(height: 300)
                        case .empty:
                            EmptyView()
                        case .failure(_):
                            EmptyView()
                        @unknown default:
                            EmptyView()
                    }
                }
            }
            Section {
                Text(movie.originalTitle ?? "")
                    .font(.largeTitle)
                    .frame(maxWidth: .infinity, alignment: .center)
                Text("Action")
                Text("Release date: \(movie.releaseDate ?? "")")
                Text("Average vote: \(movie.voteAverage ?? 0.0)")
            }
            Section {
                Text(movie.overview ?? "")
            }
            
        }
        .onAppear() {
            TheMovieDbClient().getMovieById(id: 551) { movie in
                //print(movie.originalTitle)
                self.movie = movie
            }
        }
        /*VStack {
            HStack {
                Text("Hello")
                Text(", world!")
            }
            Text("Fight Club")
                //.font(.headline)
                .font(.title)
                .foregroundColor(.red)
                .frame(height: 50)
            Text("1999-10-15")
                //.font(.headline)
                .font(.title2)
                .background(.blue)
        }*/
        
        
    }
}

struct MovieDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
