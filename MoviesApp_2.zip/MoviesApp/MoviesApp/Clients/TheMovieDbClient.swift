//
//  TheMovieDbClient.swift
//  MoviesApp
//
//  Created by Bolla Kálmán on 2022. 11. 14..
//

import Foundation

class TheMovieDbClient : ObservableObject {
    
    let baseUrl = "https://api.themoviedb.org/3/"
    let imageBaseUrl = "https://image.tmdb.org/t/p/original/"
    let apiKey = "2041ab085e31b6f0b7caa50d999b3d63"
    
    @Published var movie = MovieDetailsResponse()
    
    // részletes nézethez
    func getMovieById(id: Int,
                      completionHandler:@escaping (MovieDetailsResponse) -> ()) {
        
        // https://api.themoviedb.org/3/movie/550?api_key=xxxxxxx
        let url = URL(string: "\(baseUrl)movie/\(id)?api_key=\(apiKey)")
        
        if let url = url {
            
            /*URLSession.shared.dataTask(with: url, completionHandler: getMovieByIdHandler)*/
            
            URLSession.shared.dataTask(with: url) { data, response, error in
                
                let urlResponse = response as! HTTPURLResponse
                if urlResponse.statusCode == 200 {
                    let movie = try! JSONDecoder().decode(MovieDetailsResponse.self, from: data!)
                    print(movie.originalTitle)
                    
                    DispatchQueue.main.async {
                        completionHandler(movie)
                    }
                }
                else {
                    print("getMovieById: \(urlResponse.statusCode)")
                }
                
                
            }.resume()
        }
        else {
            print("Invalid url")
        }
    }
    
    func getMovieByIdHandler(data: Data?, response: URLResponse?, error: Error?) {
        let urlResponse = response as! HTTPURLResponse
        if urlResponse.statusCode == 200 {
            let movie = try! JSONDecoder().decode(MovieDetailsResponse.self, from: data!)
            print(movie.originalTitle)
            
            DispatchQueue.main.async {
                // TODO
            }
        }
        else {
            print("getMovieById: \(urlResponse.statusCode)")
        }
    }
    
    // lista megjelenítéshez
    func getPopularMovies() {
        
    }
}
